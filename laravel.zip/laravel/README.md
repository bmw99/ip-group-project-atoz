# Internet Programming: Group Project Assignment

Find `ip_group_project.pdf` file in this folder, and refer to all the instructions given there. 

You have to submit your project into this repository before 10.05.2019 (midnight).

